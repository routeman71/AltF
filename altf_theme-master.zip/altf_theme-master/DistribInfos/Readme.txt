CSS / vertical-responsive-menu

https://github.com/cbfranca/vertical-responsive-menu

Icons are chars in fonts.... see
http://fontawesome.io/icons


